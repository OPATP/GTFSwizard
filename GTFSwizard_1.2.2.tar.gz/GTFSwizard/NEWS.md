# GTFSwizard 1.2.2

* Barcelona regression tests exposed and fixed missing parent stations after
  filtering, which prevented filtered feeds from being reimported or merged.
* Frequency-based departures now contribute correctly to calendar counts,
  service spans, vehicle-hours, planning indicators, and time filtering.
  System frequency sums routes and directions before averaging over patterns;
  weekday-hour averages include zero departures on active dates.
* The explorer now uses OpenStreetMap tiles and keeps empty-corridor notices
  in the plot rather than repeating warnings in the console.

* Added the embedded `bcn_bus_gtfs` dataset from the supplied AMB Mobilitat
  archive `es-barcelona-autos-castellbisbal-gtfs-892.zip`: six agencies,
  128 routes, 25,122 retained trips, and 3,385 stops. The dataset uses xz
  compression; import excludes 48 trips with fewer than two stop-time records.
  All supplied calendar years (2017-2026) are retained.
* Stop-level headways process one service pattern at a time, and stop
  frequencies and dwell summaries aggregate services before expanding patterns,
  reducing memory use
  on feeds with many patterns. Services without active dates are omitted from
  service-pattern analyses rather than producing missing-weight warnings.
* `plot_calendar()` adds `max_patterns` to bound categorical legends without
  removing dates. Less frequent patterns share an "Other service patterns" color.
  Route-frequency, headway, trip-duration, and service-supply plots also accept
  `max_patterns`, defaulting to the 12 most frequent patterns; `Inf` shows all.
* Selecting the full date range in the explorer preserves every source trip;
  date comparisons no longer depend on the internal Date storage type. The
  scheduled-hours slider rounds its upper bound up to include the final hour.

* `read_gtfs()` and `write_gtfs()` now open native file-selection windows when
  their paths are omitted in interactive R sessions. Output filenames receive a
  `.zip` extension when needed.

* `read_gtfs()` converts UTF-16LE and UTF-16BE files to UTF-8 in a temporary
  copy, preserving importer options and leaving the source archive unchanged.
  A conversion warning is shown when `quiet = FALSE`.

* Added `validate_gtfs()` using the MobilityData Canonical GTFS Schedule
  Validator, with an optional SHA-256-verified download cached outside the
  package. It prints a summary, returns findings, and optionally saves HTML and
  JSON reports for a ZIP archive or exported feed object.

* Time editing functions wrap extreme edited times into the next service-day
  range while keeping stop times non-decreasing.

# GTFSwizard 1.2.1

* `split_trip()` accepts stop IDs as an alternative to an equal-part split;
  boundary stops are included in both adjacent parts.

* Refreshed the README figures and package website from the current plotting
  code, and added a reproducible figure-generation script for maintainers.

* Improved the year-faceted service calendar for dense feeds and retained the
  supplied object name in the `explore_gtfs()` dashboard.

* Organized the package website by workflow, added task-based function
  reference sections, and added vignettes for getting started, service
  analysis, filtering and editing, and the interactive dashboard.

* Standardized public method values with underscores: `by_trip`, `by_route`,
  `by_hour`, `by_stop`, and `by_shape`. Legacy dotted values remain accepted.

* Standardized public argument names including `file_path`, `gtfs_x`,
  `gtfs_y`, `max_dwelltime`, and `min_length`, with compatibility aliases for
  previous names.

* Improved `tidy_raptor()` validation, transfer handling, date selection, and
  output column names.

* Added planning indicators to `explore_gtfs()`, including scheduled headway,
  commercial speed, service span, vehicle-hours, peak fleet, stop spacing, and
  route connectivity.

* Calendar and service-pattern summaries now represent dates with no active
  service explicitly: trip counts are `0`, and the service pattern is labeled
  `"No service"`.

# GTFSwizard 1.2.0

* `plot_routefrequency()` now uses a route-hour-service pattern tile plot and
  limits the default display to the busiest routes through `top_n`, improving
  readability for large feeds.

* `explore_gtfs()` adds a route-count control for route-frequency plots and
  keeps filtered service and service-pattern selections aligned.

# GTFSwizard 1.1.1

* `create_gtfs()` introduced.

* CRAN resubmission release following archival caused by the archived
  `hrbrthemes` dependency. The dependency has been removed, and the package
  dependency set has been substantially reduced.

* GTFS editing and selection
  - `filter_stop()` and `filter_time()` now preserve partial trips for
    experimentation instead of restoring complete stop sequences.
  - `selection()` now supports grouping columns and computed groups in a style
    similar to `dplyr::group_by()`, while continuing to support logical and
    spatial selections without altering GTFS tables.

* Plotting and dashboard
  - Fixed repeated warnings and `-Inf` values when
    `shape_dist_traveled` contains only missing values.
  - `explore_gtfs()` removes duplicated system information, assigns distinct
    route colors, and filters non-finite plotting values.
  - All static plots use a shared visual theme and palette.

* Package quality
  - Added Francisco Moraes de Oliveira Neto as an author.
  - Expanded integrity, round-trip, selection, spatial, plotting, and
    regression tests.
  - Reviewed exported function documentation and GTFS logic against the
    current GTFS Schedule reference.

# GTFSwizard 1.1.0

* Now featuring travel time matrices, trip speed and dwell-time editing, corridors, hubs, and more!

* New functions
  - tidy_raptor() estimates travel time matrices from gtfs feeds;
  - edit_speed() adjusts travel speed in a GTFS dataset;
  - edit_dwelltime() modifies the dwell time of trips;
  - set_dwelltime() overwrites the dwell time of trips;
  - get_hubs() estimates high integration potential stops;
  - get_corridor() suggests "right-of-way" transit corridors;
  - plot_corridor() plots the suggested corridors from get_corridor() function;
  - get_1stdeparture() retrieves the start timepoint of each trip;
  - latlon2epsg() determines the appropriate EPSG code for a given sf object.
 
* New methods
  - get_headways() now accepts 'method = "by_stop"' and 'method = "by_shape"'.
  - get_frequency() now accepts 'method = "by_shape"' and 'method = "by_stop"'.
  
* Bug fix & improvements
  - Better column naming;
  - Minor bug fixed on filter_date() and get_shapes_sf();
  - get_headways() output fixed;
  - split_trip() can now be used after filter_time();
  - get_speeds(), get_durations() and get_distances() now accept the `trips` argument.

# GTFSwizard 1.0.0

* Initial CRAN submission.
